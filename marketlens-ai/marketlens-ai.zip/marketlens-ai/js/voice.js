/* Voice: Hindi speech input. */
$('mic').onclick=()=>{const R=window.SpeechRecognition||window.webkitSpeechRecognition;if(!R)return alert('Speech recognition is not supported in this browser. Type your request instead.');const r=new R();r.lang='hi-IN';r.onresult=e=>$('q').value=e.results[0][0].transcript;r.onerror=()=>alert('Could not hear you. Type your request instead.');r.start()};
