// App bootstrap: runs last, after all modules are loaded.
drawSrc();
