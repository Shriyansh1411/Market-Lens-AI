/* Core: DOM helpers, global state, scoring config, field aliases, navigation, theme toggle. */
const $=id=>document.getElementById(id),esc=s=>String(s??'').replace(/[&<>"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));
const S={files:[],plan:null,ents:[],cov:[],log:[],ov:{},raw:0,dup:0};
const CFG={w:{cred:.25,trace:.15,fresh:.25,comp:.2,val:.15},decay:{price_inr:[30,90],address:[365,730],def:[180,365]},cred:{official:1,secondary:.7,estimated:.4}};
const AL={name:['name','brand','company','नाम','ब्रांड'],product:['product','item','उत्पाद'],price_inr:['price','mrp','cost','price_inr','कीमत','दाम'],address:['address','पता'],pincode:['pincode','pin','zip'],city:['city','शहर'],gstin:['gstin'],cin:['cin'],fssai:['fssai'],udyam:['udyam'],date:['date','updated','collected_at']};
const NAV=[['ask','Ask'],['plan','Plan'],['dash','Dashboard'],['inspect','Inspector'],['receipt','Receipt'],['monitor','Monitors']];
$('nav').innerHTML=NAV.map(n=>`<button data-t="${n[0]}">${n[1]}</button>`).join('');
function go(t){document.querySelectorAll('section').forEach(s=>s.classList.toggle('on',s.id==t));document.querySelectorAll('nav button').forEach(b=>b.classList.toggle('on',b.dataset.t==t));try{history.replaceState(null,'','#'+t)}catch(e){}}
$('nav').onclick=e=>e.target.dataset.t&&go(e.target.dataset.t);
$('th').onclick=()=>{const r=document.documentElement;r.dataset.theme=(r.dataset.theme||(matchMedia('(prefers-color-scheme:dark)').matches?'dark':'light'))=='dark'?'light':'dark'};
