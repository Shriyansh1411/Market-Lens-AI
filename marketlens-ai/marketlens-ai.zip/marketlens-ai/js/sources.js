/* Sources: file upload, header mapping, credibility selector, sample data. */
function addFile(name,text,sample,cred){const R=csv(text);if(R.length<2)return alert('No rows found in '+name);const h=R[0].map(x=>x.trim().toLowerCase()),map={};for(const k in AL){const i=h.findIndex(x=>AL[k].includes(x));if(i>=0)map[k]=i}
if(map.name==null)return alert(name+': needs a name or brand column. Found: '+h.join(', '));S.files.push({name,sample,cred:cred||'secondary',at:new Date(),map,rows:R.slice(1)});drawSrc()}
function drawSrc(){$('src').innerHTML=S.files.map((f,i)=>`<div class="row"><b>${esc(f.name)}</b>${f.sample?'<span class="pill e">SAMPLE DATA</span>':''}<span class="mut">${f.rows.length} rows</span><select data-i="${i}" style="max-width:150px"><option value="official"${f.cred=='official'?' selected':''}>Official</option><option value="secondary"${f.cred=='secondary'?' selected':''}>Secondary</option><option value="estimated"${f.cred=='estimated'?' selected':''}>Estimated</option></select><button class="b o" data-x="${i}">Remove</button></div>`).join('')||'<p class="mut">No sources yet.</p>'}
$('src').onchange=e=>{if(e.target.dataset.i!=null)S.files[e.target.dataset.i].cred=e.target.value};$('src').onclick=e=>{if(e.target.dataset.x!=null){S.files.splice(e.target.dataset.x,1);drawSrc()}};
$('f').onchange=async e=>{for(const f of e.target.files)addFile(f.name,await f.text());e.target.value=''};
const SA=`name,Product,Price,Address,Pincode,City,Date
Haldiram's,Roasted Makhana,₹120,Pitampura,110034,Delhi,10/11/2026
Open Secret,Peanut Butter,Rs 299,Saket,110017,Delhi,01/11/2026
Yoga Bar,Muesli,INR 450,Nehru Place,110019,Delhi,12/09/2026
Too Yumm,Veggie Stix,45,Rohini,110085,Delhi,05/11/2026`,
SB=`नाम,उत्पाद,कीमत,पता,pincode,शहर,Date
हल्दीराम,Roasted Makhana,Rs. 135,"Pitampura, Delhi",110034,दिल्ली,13/11/2026
Open Secret Pvt Ltd,Peanut Butter,299,Saket,110017,Delhi,03/11/2026
Yoga Bars,Muesli,"₹ 4,60",Nehru Place,110019,Delhi,14/10/2026
Slurrp Farm,Millet Pancake Mix,0.0035 crore,Dwarka,110075,Delhi,08/11/2026`;
$('smp').onclick=()=>{addFile('sample_official.csv',SA,1,'official');addFile('sample_retail.csv',SB,1,'secondary')};
