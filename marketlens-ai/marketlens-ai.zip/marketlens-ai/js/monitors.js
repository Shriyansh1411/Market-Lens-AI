/* Monitors: localStorage snapshots and diffing. */
const snap=()=>Object.fromEntries(S.ents.map(e=>[e.key+'|'+e.pk,{n:e.display,p:pc(e)??null}]));
const ls=()=>{try{return JSON.parse(localStorage.getItem('ml_snaps')||'[]')}catch(e){return[]}};
function mlist(){$('mo').innerHTML=ls().map(s=>`<div class="mut">Saved: ${esc(s.name)}, ${s.at.slice(0,16)}, ${Object.keys(s.d).length} records</div>`).join('')}mlist();
$('sv').onclick=()=>{if(!S.ents.length)return alert('Run research first.');const a=ls();a.push({name:$('mn').value||S.plan.topic,at:new Date().toISOString(),d:snap()});try{localStorage.setItem('ml_snaps',JSON.stringify(a))}catch(e){alert('Browser storage is unavailable here.')}mlist()};
$('cmp').onclick=()=>{const a=ls();if(!a.length||!S.ents.length)return alert('Save a snapshot, then run research again with updated files.');const o=a[a.length-1].d,n=snap(),out=[];for(const k in n){if(!o[k])out.push(`<div><span class="pill v">added</span> ${esc(n[k].n)}</div>`);else if(o[k].p!=n[k].p)out.push(`<div><span class="pill e">changed</span> ${esc(n[k].n)} price ₹${o[k].p} to ₹${n[k].p}</div>`)}for(const k in o)if(!n[k])out.push(`<div><span class="pill bad">removed</span> ${esc(o[k].n)}</div>`);
$('mo').innerHTML='<h2 style="margin-top:12px">Changes since '+a[a.length-1].at.slice(0,16)+'</h2>'+(out.join('')||'<p class="mut">No changes.</p>')};
