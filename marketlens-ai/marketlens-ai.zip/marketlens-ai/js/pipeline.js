/* Pipeline: filter, clean, entity-merge, conflict resolution and trust scoring. */
const tick=()=>new Promise(r=>setTimeout(r,120));
$('run').onclick=async()=>{const p=S.plan;p.topic=$('p_t').value;p.location=$('p_l').value.trim();p.fields=$('p_f').value.split(',').map(x=>x.trim()).filter(Boolean);p.rule=$('p_r').value;S.ov={};
const ST=['Understanding request','Creating plan','Connecting to sources','Collecting records','Cleaning data','Validating records','Generating insights','Preparing dashboard'];$('stg').innerHTML=ST.map(s=>`<div>${s}</div>`).join('');
const step=async i=>{$('stg').children[i].className='done';await tick()};await step(0);await step(1);await step(2);
const rows=[];let raw=0;S.log=[];
for(const f of S.files){for(const r of f.rows){raw++;const g=k=>f.map[k]!=null?(r[f.map[k]]||'').trim():'';const city=CITY[g('city')]||g('city'),addr=g('address');
if(p.location&&(city||addr)&&!(city+' '+addr).toLowerCase().includes(p.location.toLowerCase()))continue;const D=dt(g('date'));
const row={name:g('name'),product:g('product'),at:D.d||f.at,amb:D.amb,f,cl:{}};
for(const k of ['product','price_inr','address','pincode','city','gstin','cin','fssai','udyam']){let v=k=='city'?city:g(k);if(!v)continue;if(k=='price_inr'){const n=money(v);if(n==null)continue;if(String(n)!=v)S.log.push(`${v} → ₹${n} (${f.name})`);v=n}if(k=='gstin'||k=='cin')v=v.toUpperCase();row.cl[k]=v}
rows.push(row)}}await step(3);
const E=[];for(const r of rows){const key=nk(r.name),pk=nk(r.product);let best=null,bs=0,why='';for(const e of E){const sameId=r.cl.gstin&&e.ids.gstin&&r.cl.gstin==e.ids.gstin;const s=sameId?1:lev(key,e.key);if(pk==e.pk&&s>bs){bs=s;best=e;why=sameId?'GSTIN match':`name similarity ${(s*100|0)}%`}}
if(best&&bs>=.8){best.rows.push(r);best.reasons.push(`${r.name} (${r.f.name}) matched ${best.names[0]}: ${why}`);if(!best.names.includes(r.name))best.names.push(r.name)}else E.push({key,pk,names:[r.name],rows:[r],ids:{gstin:r.cl.gstin},reasons:[]})}
await step(4);S.raw=raw;S.ents=E;S.dup=raw-rows.length;resolve();await step(5);await step(6);await step(7);
$('stg').insertAdjacentHTML('beforeend','<div class="mut">Finished. Opening dashboard.</div>');await tick();draw();go('dash')};
const age=d=>(Date.now()-d)/864e5;
function resolve(){const rule=S.plan.rule,fl=S.plan.fields.filter(f=>f!='name');S.cov=fl.map(f=>({f,src:[...new Set(S.ents.flatMap(e=>e.rows.filter(r=>r.cl[f]!=null).map(r=>r.f.name)))]}));
S.ents.forEach((e,ei)=>{e.id=ei;e.F={};const keys=new Set(['name',...fl]);for(const k of keys){const cl=k=='name'?e.rows.map(r=>({v:r.name,r})):e.rows.filter(r=>r.cl[k]!=null).map(r=>({v:r.cl[k],r}));if(!cl.length){e.F[k]={status:'no_data',claims:[]};continue}
const C=cl.map(c=>({v:c.v,src:c.r.f.name,at:c.r.at,cred:CFG.cred[c.r.f.cred],cl:c.r.f.cred,label:c.r.f.cred=='estimated'?'estimated':'verified',amb:c.r.amb}));const vs=new Set(C.map(c=>k=='name'?nk(c.v):String(c.v).toLowerCase()));
const o=S.ov[ei+'|'+k];let st='agreed',res=null,ch=C[0];
if(o!=null){st='conflict';ch=C[o];res={rule:'user_override',chosen:ch.v,by_user:true}}else if(vs.size>1){st='conflict';const sc=c=>rule=='most_recent'?+c.at:rule=='most_credible'?c.cred:(c.cl=='official'?1:0);const srt=[...C].sort((a,b)=>sc(b)-sc(a));if(sc(srt[0])==sc(srt[1])&&String(srt[0].v)!=String(srt[1].v)){st='unresolved';ch=null}else{ch=srt[0];res={rule,chosen:ch.v}}}
e.F[k]={status:st,claims:C,res,ch}}
e.display=e.F.name.ch?.v||e.names[0];e.ids2={};for(const k of ['gstin','cin','fssai','udyam']){const c=e.rows.find(r=>r.cl[k]);if(c)e.ids2[k]=[c.cl[k],idOk(k,c.cl[k])]}
const ch=Object.entries(e.F).filter(([k,v])=>v.ch&&k!='name'),req=fl.length;
const cred=ch.length?ch.reduce((a,[,v])=>a+v.ch.cred,0)/ch.length:0,
fresh=ch.length?ch.reduce((a,[k,v])=>{const [x,y]=CFG.decay[k]||CFG.decay.def,d=age(v.ch.at);const b=d<=x?1:d<=y?.6:.2;v.fr=d<=x?'fresh':d<=y?'aging':'stale';v.age=Math.round(d);return a+b},0)/ch.length:0,
comp=req?ch.length/req:1,ids=Object.values(e.ids2),val=ids.length?ids.filter(x=>x[1]).length/ids.length:.8;
const w=CFG.w,sc=cred*w.cred+w.trace+fresh*w.fresh+comp*w.comp+val*w.val;e.score=sc;e.band=sc>=.75?'High':sc>=.55?'Medium':'Low';
const n=(x,hi,lo)=>x>=hi?'raises':x<lo?'lowers':'neutral';
e.why=[['Source credibility',n(cred,.8,.6),`avg ${(cred*100|0)}%`],['Traceability','raises','every value has a source and timestamp'],['Freshness',n(fresh,.8,.5),`avg ${(fresh*100|0)}%`],['Completeness',n(comp,.9,.6),`${ch.length}/${req} requested fields`],['Validation',n(val,.9,.6),ids.length?`${ids.filter(x=>x[1]).length}/${ids.length} IDs have valid format`:'no identifiers supplied']]})}
