/* Receipt: SHA-256 dataset hash + HMAC-signed research receipt. */
const canon=o=>Array.isArray(o)?'['+o.map(canon)+']':o&&typeof o=='object'?'{'+Object.keys(o).sort().map(k=>JSON.stringify(k)+':'+canon(o[k]))+'}':JSON.stringify(o);
const hex=b=>[...new Uint8Array(b)].map(x=>x.toString(16).padStart(2,'0')).join('');
let KEY;async function sha(t){return hex(await crypto.subtle.digest('SHA-256',new TextEncoder().encode(t)))}
$('mr').onclick=async()=>{if(!S.ents.length)return alert('Run research first.');try{const data=flat(),h=await sha(canon(data));KEY=KEY||await crypto.subtle.generateKey({name:'HMAC',hash:'SHA-256'},false,['sign']);
const rc={query:S.plan.query,plan:S.plan,sources:S.files.map(f=>({name:f.name,credibility:f.cred,sample:!!f.sample,rows:f.rows.length})),rules:{conflict:S.plan.rule,trust_weights:CFG.w,freshness_days:CFG.decay},generated_at:new Date().toISOString(),dataset_sha256:h,records:data.length};
rc.signature_hmac_sha256=hex(await crypto.subtle.sign('HMAC',KEY,new TextEncoder().encode(canon(rc))));S.rc=rc;$('rp').textContent=JSON.stringify(rc,null,2)}catch(e){$('rp').textContent='Receipt failed: '+e.message}};
$('dr').onclick=()=>S.rc?dl('research_receipt.json',JSON.stringify(S.rc,null,2),'application/json'):alert('Generate the receipt first.');
