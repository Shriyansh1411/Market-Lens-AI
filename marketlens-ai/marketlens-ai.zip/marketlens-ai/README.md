# MarketLens AI

Browser-only prototype that turns a plain-language request (English or Hindi) plus CSV sources you upload into a cleaned, de-duplicated dataset with conflict handling, trust scores, provenance, a signed research receipt and change monitoring. Nothing is invented: missing data is reported as missing.

## Run
No build step. Open `index.html` in a browser, or serve the folder:

    npx serve .        # or: python3 -m http.server 8000

## Structure
    index.html            page markup (6 views: Ask, Plan, Dashboard, Inspector, Receipt, Monitors)
    css/styles.css        theme tokens (light/dark) and layout
    js/core.js            helpers, global state S, scoring config CFG, header aliases, nav, theme
    js/normalize.js       CSV parser, money/date parsing, Devanagari transliteration, fuzzy match, ID validators
    js/sources.js         CSV upload, header mapping, credibility, sample data
    js/interpreter.js     request -> plan (location, fields, conflict rule)
    js/pipeline.js        filter, clean, merge entities, resolve conflicts, trust score
    js/dashboard.js       KPIs, chart, insights, table, inspector, CSV export
    js/receipt.js         SHA-256 + HMAC-signed receipt
    js/monitors.js        snapshots in localStorage and diff
    js/voice.js           Web Speech API input (hi-IN)
    js/main.js            bootstrap
    sample-data/          two demo CSVs

Scripts are classic (non-module) and share a global scope, so keep the load order in `index.html`.

## Key tuning points
- `CFG` in `js/core.js`: trust weights, freshness decay days per field, credibility values.
- `AL` in `js/core.js`: accepted CSV header names (English and Hindi).
- `CITY` / `FK` in `js/interpreter.js`: Hindi city names and field keywords.

## Limitations
- Receipt key is generated per browser session (prototype); it proves the export was not altered, not that sources are correct.
- GSTIN/CIN/FSSAI/Udyam checks are format checks only.
- Only user-uploaded CSVs are read; there is no scraping or backend.
